var AddContracts = artifacts.require("./AddContracts.sol");

module.exports = function(deployer) {
  deployer.deploy(AddContracts);
};